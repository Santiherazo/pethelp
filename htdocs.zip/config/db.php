<?php 

class DatabaseConnection {
    private $dbHost;
    private $dbUser;
    private $dbPassword;
    private $dbName;
    private $conn;

    public function __construct($host, $user, $password, $name) {
        $this->dbHost = $host;
        $this->dbUser = $user;
        $this->dbPassword = $password;
        $this->dbName = $name;
    }

    public function connect() {
        $this->conn = new mysqli($this->dbHost, $this->dbUser, $this->dbPassword, $this->dbName);

        if ($this->conn->connect_error) {
            die("Error de conexión: " . $this->conn->connect_error);
        }
    }

    public function executeQuery($query) {
        $result = $this->conn->query($query);

        if (!$result) {
            die("Error en la consulta: " . $this->conn->error);
        }

        return $result;
    }

    public function closeConnection() {
        $this->conn->close();
    }
}