<?php 

require_once('db.php');
$db = new DatabaseConnection('localhost', 'root', '', 'pethelp');

session_start();

function sesionActiva() {
    return (isset($_SESSION['name']) && isset($_SESSION['role']));
}