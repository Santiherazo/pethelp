const PATHS = {
  home: {
      path: "/",
      template:`
      <div class="carousel-item w-full">
        <div class="hero min-h-screen" style="background-image:url(https://cdn.pixabay.com/photo/2016/01/01/02/01/animal-welfare-1116205_1280.jpg);filter:blur(0.5)">
            <div class="hero-overlay bg-opacity-60"></div>
                <div class="hero-content text-center text-neutral-content">
                    <div class="max-w-md">
                        <h1 class="mb-5 text-5xl font-bold" style="color:#D74E09">Pet°help</h1>
                        <p class="mb-5" style="color:#F0F0C9">Nuestra misión: Rescatar, cuidar, y amar a los que no pueden pedir ayuda.</p>
                        <a class="btn" style="border: 1px solid #D74E09; background:none;color:#D74E09;font-weight:bold;" href="#donaciones">Ayúdanos a salvar vidas</a>
                    </div>
                </div>
            </div>
        </div> 

        <div style="background-color:#F0F0C9">
            <div class="mx-auto max-w-2xl px-4 py-16 sm:px-6 sm:py-10 lg:max-w-7xl lg:px-8">
                <h2 class="text-2xl font-bold tracking-tight text-gray-900">Rescates Recientes</h2>
                <div class="mt-6 grid grid-cols-1 gap-x-6 gap-y-10 sm:grid-cols-2 lg:grid-cols-4 xl:gap-x-8">
                      
                <div class="group relative">
                    <div class="aspect-h-1 aspect-w-1 w-full overflow-hidden rounded-md bg-gray-200 lg:aspect-none group-hover:opacity-75 lg:h-80">
                        <img src="https://img.freepik.com/free-photo/cute-dogs-fence-waiting-be-adopted_23-2148683005.jpg?w=740&t=st=1699514603~exp=1699515203~hmac=7536bceafefad1592cac306b50a98c55de83fee6dfa7a6dd7620bcd6bd7e059d" alt="Front of men&#039;s Basic Tee in black." class="h-full w-full object-cover object-center lg:h-full lg:w-full">
                    </div>
                    <div class="mt-4 flex justify-between">
                        <div>
                                  <h3 class="text-sm text-gray-700">
                                      <a href="#">
                                      <span aria-hidden="true" class="absolute inset-0"></span>Nombre: Billie</a>
                                  </h3>
                                  <p class="mt-1 text-sm text-gray-500">Rescatado por: Maltrato animal</p>
                              </div>
                              <p class="text-sm font-medium text-gray-900">Edad: 2 Meses</p>
                          </div>
                      </div>

                  </div>
              </div>
          </div>

          <div class="bg-white py-24 sm:py-10" style="background:#D74E09;">
              <div class="mx-auto max-w-7xl px-6 lg:px-8">
                  <dl class="grid grid-cols-1 gap-x-8 gap-y-16 text-center lg:grid-cols-3">
                      <div class="mx-auto flex max-w-xs flex-col gap-y-4">
                          <dt class="text-base leading-7 text-gray-600" style="color:#F0F0C9">Mascotas rescatados</dt>
                          <dd class="order-first text-3xl font-semibold tracking-tight text-gray-900 sm:text-5xl" style="color:#F0F0C9">+400</dd>
                      </div>
                      <div class="mx-auto flex max-w-xs flex-col gap-y-4">
                          <dt class="text-base leading-7 text-gray-600" style="color:#F0F0C9">Mascotas adoptadas</dt>
                          <dd class="order-first text-3xl font-semibold tracking-tight text-gray-900 sm:text-5xl" style="color:#F0F0C9">+100</dd>
                      </div>
                      <div class="mx-auto flex max-w-xs flex-col gap-y-4">
                          <dt class="text-base leading-7 text-gray-600" style="color:#F0F0C9">Mascotas beneficiadas</dt>
                          <dd class="order-first text-3xl font-semibold tracking-tight text-gray-900 sm:text-5xl" style="color:#F0F0C9">+1000</dd>
                      </div>
                  </dl>
              </div>
          </div>

          <div class="overflow-hidden bg-white py-24 sm:py-32">
              <div class="mx-auto max-w-7xl px-6 lg:px-8">
                  <div class="mx-auto grid max-w-2xl grid-cols-1 gap-x-8 gap-y-16 sm:gap-y-20 lg:mx-0 lg:max-w-none lg:grid-cols-2">
                      <div class="lg:pr-8 lg:pt-4">
                          <div class="lg:max-w-lg">
                              <h2 class="text-base font-semibold leading-7 text-indigo-600" style="color:#D74E09;font-size:20px">Pet°Help: Tu Compañero en la Protección Animal</h2>
                              <p class="mt-2 text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">¿Quienes somos?</p>
                              <p class="mt-6 text-lg leading-8 text-gray-600">En PetHelp, nuestra misión es simple pero poderosa: defender y proteger a los animales más vulnerables de nuestra sociedad. Como una fundación dedicada al bienestar animal, nos enorgullece ser la voz y el refugio para aquellos que no pueden hablar por sí mismos.</p>
                              <dl class="mt-10 max-w-xl space-y-8 text-base leading-7 text-gray-600 lg:max-w-none">
                                  <div class="relative pl-9">
                                      <dt class="inline font-semibold text-gray-900">
                                          <svg class="absolute left-1 top-1 h-5 w-5 text-indigo-600" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                              <path fill-rule="evenodd" d="M10 1a4.5 4.5 0 00-4.5 4.5V9H5a2 2 0 00-2 2v6a2 2 0 002 2h10a2 2 0 002-2v-6a2 2 0 00-2-2h-.5V5.5A4.5 4.5 0 0010 1zm3 8V5.5a3 3 0 10-6 0V9h6z" clip-rule="evenodd" />
                                          </svg>
                                          Empatía:
                                      </dt>
                                      <dd class="inline"> La empatía es una cualidad fundamental de PetHelp, que se refleja en su trato compasivo hacia cada ser viviente.</dd>
                                  </div>
                                  <div class="relative pl-9">
                                      <dt class="inline font-semibold text-gray-900">
                                          <svg class="absolute left-1 top-1 h-5 w-5 text-indigo-600" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                              <path fill-rule="evenodd" d="M10 1a4.5 4.5 0 00-4.5 4.5V9H5a2 2 0 00-2 2v6a2 2 0 002 2h10a2 2 0 002-2v-6a2 2 0 00-2-2h-.5V5.5A4.5 4.5 0 0010 1zm3 8V5.5a3 3 0 10-6 0V9h6z" clip-rule="evenodd" />
                                          </svg>
                                          Trabajo en Equipo: 
                                      </dt>
                                      <dd class="inline">El equipo de PetHelp trabaja unido y de manera colaborativa para alcanzar sus objetivos y brindar el mejor cuidado posible a los animales..</dd>
                                  </div>
                                  <div class="relative pl-9">
                                      <dt class="inline font-semibold text-gray-900">
                                          <svg class="absolute left-1 top-1 h-5 w-5 text-indigo-600" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                              <path fill-rule="evenodd" d="M10 1a4.5 4.5 0 00-4.5 4.5V9H5a2 2 0 00-2 2v6a2 2 0 002 2h10a2 2 0 002-2v-6a2 2 0 00-2-2h-.5V5.5A4.5 4.5 0 0010 1zm3 8V5.5a3 3 0 10-6 0V9h6z" clip-rule="evenodd" />
                                          </svg>
                                          Innovación y Mejora Continua:
                                      </dt>
                                      <dd class="inline">PetHelp busca constantemente nuevas formas de mejorar y ampliar su impacto en la protección animal.</dd>
                                  </div>
                              </dl>
                          </div>
                      </div>
                      <img src="https://img.freepik.com/free-photo/man-hugging-his-friendly-pitbull_23-2149131403.jpg?w=740&t=st=1699512753~exp=1699513353~hmac=462d0976f65bdd1ecad9f0b0f87080e009a1d8922785b22af08e5b466fb7e191" alt="Product screenshot" class="w-[48rem] max-w-none rounded-xl shadow-xl ring-1 ring-gray-400/10 sm:w-[57rem] md:-ml-4 lg:-ml-0" width="2432" height="1442">
                  </div>
              </div>
          </div>


          <div style="background:#D74E09">
              <div class="mx-auto max-w-7xl py-24 sm:px-6 sm:py-10 lg:px-8">
                  <div class="relative isolate overflow-hidden bg-gray-900 px-6 pt-16 shadow-2xl sm:rounded-3xl sm:px-16 md:pt-24 lg:flex lg:gap-x-20 lg:px-24 lg:pt-0" style="background:#F0F0C9">
                      <div class="mx-auto max-w-md text-center lg:mx-0 lg:flex-auto lg:py-32 lg:text-left">
                          <h2 style="color:#434343" class="text-3xl font-bold tracking-tight text-white sm:text-4xl">¡Llévame contigo!<br>Seré tu mejor compañia.</h2>
                          <p style="color:#434343" class="mt-6 text-lg leading-8 text-gray-300">Las almas más leales no tienen pedigrí, tienen amor para dar.</p>
                          <div class="mt-10 flex items-center justify-center gap-x-6 lg:justify-start">
                              <a href="#" style="color:#434343" class="rounded-md bg-white px-3.5 py-2.5 text-sm font-semibold text-gray-900 shadow-sm hover:bg-gray-100 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white">Adóptame</a>
                          </div>
                      </div>
                      <div class="relative mt-16 h-80 lg:mt-8">
                          <img class="absolute left-0 top-0 w-[29rem] max-w-none rounded-md bg-white/5 ring-1 ring-white/10" src="https://img.freepik.com/free-photo/adorable-dog-with-adopt-me-banner_23-2148699618.jpg?w=740&t=st=1699513087~exp=1699513687~hmac=f01166e091ec33de73d5364a9fb9c338ea892fdedc423d1351a27d3ff8373608" alt="App screenshot">
                      </div>
                  </div>
              </div>
          </div>
      
      `,
  },
  nosotros: {
      path: "/nosotros",
      template: `nosotros`,
  },
  donaciones: {
    path: "/donaciones",
    template: `donaciones`,
},
adopcion: {
  path: "/adopcion",
  template: `
    <div style="display:flex;justify-content:center;align-items:center">
        <div class="join w-100">
            <input class="input input-bordered join-item w-90" placeholder="Search"/>
            <select class="select select-bordered join-item w-90">
                <option disabled selected>Filter</option>
                <option>Sci-fi</option>
                <option>Drama</option>
                <option>Action</option>
            </select>
            <div class="indicator w-90">
                <span class="indicator-item badge badge-secondary">new</span> 
                <button class="btn join-item">Search</button>
            </div>
        </div>
    </div>
    <div style="background-color:#F0F0C9">
    <div class="mx-auto max-w-2xl px-4 py-16 sm:px-6 sm:py-10 lg:max-w-7xl lg:px-8">
        <h2 class="text-2xl font-bold tracking-tight text-gray-900">Mascotas en adopción</h2>
        <div class="mt-6 grid grid-cols-1 gap-x-6 gap-y-10 sm:grid-cols-2 lg:grid-cols-4 xl:gap-x-8" id="view">
        </div>
    </div>
</div>



  `,
},
pqrs: {
  path: "/pqrs",
  template: `pqrs`,
},
  contacto: {
      path: "/contacto",
      template: `contacto`,
  }
}

class Router {
  constructor(paths) {
          this.paths = paths;
          this.initRouter();
      }

      initRouter() {
      const { location: { pathname = "/" } } = window;
      const URL = pathname === "/" ? "home" : pathname.replace("/", "");
      this.load(URL);
  }

  load(page = "home") {
      const { paths } = this;
      const { path, template } = paths[page] || paths.error;
      const $CONTAINER = document.querySelector("#content");
      $CONTAINER.innerHTML = template;
      window.history.pushState({}, "done", path);
  }
}

const ROUTER = new Router(PATHS);