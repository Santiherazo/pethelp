

// Logout Function
document.getElementById('logoutSession').addEventListener('click', cerrarSesion);

function cerrarSesion() {
    fetch('modules/logout.php', {
        method: 'POST',
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                console.log(data.message);
                location.reload();
            } else {
                console.log(data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
}

// Reports Function
let latitude;
let longitude;

document.getElementById('gps.report').addEventListener('click', function(){
    LocationGPS();
});

function LocationGPS() {
    if ("geolocation" in navigator) {
        navigator.geolocation.getCurrentPosition(function (position) {
            latitude = position.coords.latitude;
            longitude = position.coords.longitude; 

            if (latitude && longitude) {
                fetch(`http://www.coordenadas-gps.com/latitud-longitud/${latitude}/${longitude}/30/roadmap`)
                    .then(response => response.text())
                    .then(data => {
                        // Asegúrate de tener un elemento con id "maps" para mostrar el mapa.
                        document.getElementById("maps").src = data;
                    })
                    .catch(error => {
                        console.error("Hubo un error al realizar la solicitud:", error);
                    });
            } else {
                alert("Por favor, ingresa valores de latitud y longitud.");
            }
        });
    }
}


function sendReport(typeReport, animal, description, files, location, latitude, longitude) {
    const formData = new FormData();
    formData.append('typeReport', typeReport);
    formData.append('animal', animal);
    formData.append('description', description);
    formData.append('location', location);
    formData.append('latitude', latitude);
    formData.append('longitude', longitude);

    for (let i = 0; i < files.length; i++) {
        formData.append('file[]', files[i]);
    }

    const xhr = new XMLHttpRequest();
    const url = 'modules/reports.php';

    return new Promise(function (resolve, reject) {
        xhr.open('POST', url, true);
        xhr.onload = function () {
            if (xhr.status === 200) {
                resolve(xhr.responseText);
            } else {
                reject(xhr.statusText);
            }
        };
        xhr.onerror = function () {
            reject(xhr.statusText);
        };
        xhr.send(formData);
    })
        .then(function (response) {
            console.log(response);
        })
        .catch(function (error) {
            console.error('Error:', error);
        });
}

document.getElementById('submit_demand').addEventListener('click', function () {
    let typeReport = document.getElementById('type.report').value;
    let animal = document.getElementById('animal.report').value;
    let description = document.getElementById('description.report').value;
    let location = document.getElementById('ubi.report').value;
    let fileUpload = document.getElementById('fileUpload');
    const files = fileUpload.files;
    sendReport(typeReport, animal, description, files, location, latitude, longitude);

});

document.getElementById('gps.report').addEventListener('click', function(){
    alert();
});
function LocationGPS() {
    if ("geolocation" in navigator) {
        navigator.geolocation.getCurrentPosition(function (position) {
            var latitude = position.coords.latitude;
            var longitude = position.coords.longitude; 
      
    if (latitude && longitude) {
        fetch(`http://www.coordenadas-gps.com/latitud-longitud/${latitude}/${longitude}/30/roadmap`)
            .then(response => response.text())
            .then(data => {
                document.getElementById("maps").src = data;
            })
            .catch(error => {
                console.error("Hubo un error al realizar la solicitud:", error);
            });
    } else {
        alert("Por favor, ingresa valores de latitud y longitud.");
    }
});
}
}

function checkPassword(password) {
    const longitudMinima = 8;
    const contieneMayuscula = /[A-Z]/.test(password);
    const contieneMinuscula = /[a-z]/.test(password);
    const contieneNumero = /[0-9]/.test(password);
    const contieneCaracterEspecial = /[!@#\$%\^&\*]/.test(password);

    const errores = [];

    if (password.length < longitudMinima) {
        errores.push('La contraseña debe tener al menos ' + longitudMinima + ' caracteres.');
    }

    if (!contieneMayuscula) {
        errores.push('La contraseña debe contener al menos una letra mayúscula.');
    }

    if (!contieneMinuscula) {
        errores.push('La contraseña debe contener al menos una letra minúscula.');
    }

    if (!contieneNumero) {
        errores.push('La contraseña debe contener al menos un número.');
    }

    if (!contieneCaracterEspecial) {
        errores.push('La contraseña debe contener al menos un carácter especial.');
    }

    if (errores.length > 0) {
        document.getElementById('advertisement').innerHTML = errores.join('<br>');
        return false;
    } else {
        document.getElementById('advertisement').innerHTML = '';
        return true;
    }
}

function autopass() {
    const caracteresMayusculas = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const caracteresMinusculas = 'abcdefghijklmnopqrstuvwxyz';
    const numeros = '0123456789';
    const caracteresEspeciales = '!@#$%^&*()_+-=[]{}|;:,.<>?';

    const caracteresPermitidos = caracteresMayusculas + caracteresMinusculas + numeros + caracteresEspeciales;

    let contraseñaGenerada = '';

    contraseñaGenerada += caracteresMayusculas[Math.floor(Math.random() * caracteresMayusculas.length)];
    contraseñaGenerada += caracteresMinusculas[Math.floor(Math.random() * caracteresMinusculas.length)];
    contraseñaGenerada += numeros[Math.floor(Math.random() * numeros.length)];
    contraseñaGenerada += caracteresEspeciales[Math.floor(Math.random() * caracteresEspeciales.length)];

    for (let i = 4; i < 15; i++) {
        contraseñaGenerada += caracteresPermitidos[Math.floor(Math.random() * caracteresPermitidos.length)];
    }

    contraseñaGenerada = contraseñaGenerada.split('').sort(function(){return 0.5-Math.random()}).join('');

    setTimeout(function() {
        document.getElementById('password').type = "password";
        document.getElementById('passchek').type = "password";
    }, 120000);
    document.getElementById('password').type = "text";
    document.getElementById('passchek').type = "text";
    document.getElementById('password').value = contraseñaGenerada;
    document.getElementById('passchek').value = contraseñaGenerada;
}