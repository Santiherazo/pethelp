<template id="nosotros">
    Nosotros
</template>

<template id="donaciones">
    Donaciones
</template>

<template id="adopciones">
    Adopciones
</template>

<template id="pqrs">
    PQRS
</template>

<template id="contacto">
    Contacto
</template>

