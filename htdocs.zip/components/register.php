<h3 class="font-bold text-center text-lg mb-3">Registro</h3>
<div class="flex w-full mb-4">
    <div class="grid flex-grow card rounded-box place-items-center">
        <div class="join join-vertical">
            <div class="form-control w-full max-w-xs join-item">
                <label class="label">
                    <span class="label-text">Primer Nombre</span>
                </label>
                <input id="fname" type="text" class="input input-bordered w-full max-w-xs input-sm bg-secondary-content" />
            </div>
            <div class="form-control w-full max-w-xs join-item">
                <label class="label">
                    <span class="label-text">Segundo Nombre</span>
                </label>
                <input id="sname" type="text" class="input input-bordered w-full max-w-xs input-sm bg-secondary-content" />
            </div>
            <div class="form-control w-full max-w-xs join-item">
                <label class="label">
                    <span class="label-text">Primer Apellido</span>
                </label>
                <input id="flastname" type="text" class="input input-bordered w-full max-w-xs input-sm bg-secondary-content" />
            </div>
            <div class="form-control w-full max-w-xs join-item">
                <label class="label">
                    <span class="label-text">Segundo Apellido</span>
                </label>
                <input id="slastname" type="text" class="input input-bordered w-full max-w-xs input-sm bg-secondary-content" />
            </div>
            <div class="form-control w-full max-w-xs join-item">
                <label class="label">
                    <span class="label-text">Ciudad</span>
                </label>
                <input id="city" type="text" class="input input-bordered w-full max-w-xs input-sm bg-secondary-content" />
            </div>
        </div>
    </div>
    <div class="grid flex-grow card rounded-box place-items-center">   
        <div class="join join-vertical">
            <div class="form-control w-full max-w-xs join-item">
                <label class="label">
                    <span class="label-text">Correo Electrónico</span>
                </label>
                <input id="email" type="email" class="input input-bordered w-full max-w-xs input-sm bg-secondary-content" />
            </div>
            <div class="form-control w-full max-w-xs join-item">
                <label class="label">
                    <span class="label-text">Celular</span>
                </label>
                <input id="phone" type="text" class="input input-bordered w-full max-w-xs input-sm bg-secondary-content" />
            </div>
                            <div class="form-control w-full max-w-xs join-item">
                                <label class="label">
                                    <span class="label-text">Contraseña</span>
                                </label>
                                <input id="password" type="password" class="input input-bordered w-full max-w-xs input-sm bg-secondary-content" />
                                <label class="label">
                                    <span id="advertisement" class="label-text-alt"></span>
                                    <span class="label-text-alt hide">Mostrar</span>
                                </label>
                            </div>
                            <div class="form-control w-full max-w-xs join-item">
                                <label class="label">
                                    <span class="label-text">Confirmar Contraseña</span>
                                </label>
                                <input id="passchek" type="password" class="input input-bordered w-full max-w-xs input-sm bg-secondary-content" />
                                <label class="label">
                                    <span id="matches" class="label-text-alt"></span>
                                    <span class="label-text-alt hide">Mostrar</span>
                                </label>
                            </div>
                            <button id="auto-pass" class="btn btn-sm btn-outline btn-block">Generar contraseña</button>
                        </div>
                    </div>
                </div>
                <button id="register" class="btn btn-sm btn-outline btn-block">Registrarse</button>

<script>
let checked;
let matched;

document.addEventListener("DOMContentLoaded", function () {

    document.getElementById('auto-pass').addEventListener('click', autopass);
    document.getElementById('password').addEventListener('keyup', function() {
        let password = document.getElementById('password').value;
        checked = checkPassword(password);
    });
    document.getElementById('passchek').addEventListener('keyup', function(){
        let password = document.getElementById('password').value;
        let passcheck = document.getElementById('passchek').value;
        if (password === passcheck) {
        document.getElementById('matches').innerHTML = 'Las contraseñas coinciden';
        matched = true;
        setTimeout(() => {
            document.getElementById('matches').innerHTML = '';
        }, 5000);
    } else {
        matched = false;
        document.getElementById('matches').innerHTML = 'Las contraseñas no coinciden.';
    }
    });

    document.getElementById('register').addEventListener('click', function(){
        let fnameInput = document.getElementById('fname').value;
        let snameInput = document.getElementById('sname').value;
        let flastnameInput = document.getElementById('flastname').value;
        let slastnameInput = document.getElementById('slastname').value;
        let cityInput = document.getElementById('city').value;
        let emailInput = document.getElementById('email').value;
        let phoneInput = document.getElementById('phone').value;
        let passwordInput = document.getElementById('password').value;
        let passchekInput = document.getElementById('passchek').value;
        register(fnameInput, snameInput, flastnameInput, slastnameInput, cityInput, emailInput, phoneInput, passwordInput, passchekInput, checked, matched);
    });

    function register(fnameInput, snameInput, flastnameInput, slastnameInput, cityInput, emailInput, phoneInput, passwordInput, passchekInput, checked, matched) {
    if (!fnameInput || !snameInput || !flastnameInput || !slastnameInput || !cityInput || !emailInput || !phoneInput || !passwordInput || !passchekInput) {
        console.error('Por favor, complete todos los campos.');
        return;
    }

    const formData = new FormData();
    formData.append('fnameInput', fnameInput);
    formData.append('snameInput', snameInput);
    formData.append('flastnameInput', flastnameInput);
    formData.append('slastnameInput', slastnameInput);
    formData.append('cityInput', cityInput);
    formData.append('emailInput', emailInput);
    formData.append('phoneInput', phoneInput);
    formData.append('passwordInput', passwordInput);
    formData.append('passchekInput', passchekInput);
    formData.append('checked', checked);
    formData.append('matched', matched);

    const xhr = new XMLHttpRequest();
    const url = 'modules/register.php';

    xhr.open('POST', url, true);
    xhr.onload = function () {
        if (xhr.status === 200) {
            const response = JSON.parse(xhr.responseText); // Analizar la respuesta JSON
            if (response.success === true) {
                location.reload();
            }
        } else {
            console.error('Error en la solicitud: ' + xhr.statusText);
        }
    };
    xhr.onerror = function () {
        console.error('Error en la solicitud.');
    };
    xhr.send(formData);
}
});
</script>