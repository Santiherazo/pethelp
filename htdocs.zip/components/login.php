<div class="join join-vertical lg:join-horizontal">
    <div class="form-control w-full max-w-xs">
        <input id="email.login" type="email" placeholder="Correo Electrónico" class="input input-bordered input-sm w-full max-w-xs mb-2 bg-secondary-content" />
        <input id="password.login" type="password" placeholder="Contraseña" class="input input-bordered input-sm w-full max-w-xs mb-2 bg-secondary-content" />
        <button id="btn.login" class="btn btn-sm btn-outline">Iniciar Sesión</button>
        <label class="label text-base-100">
            <span class="label-text-alt"><a href="">¿Olvidaste tu contraseña?</a></span>
            <span class="label-text-alt"><a onclick="register_modal.showModal()">Registrarse</a></span>
        </label>
    </div>
</div>

<script>
    document.addEventListener("DOMContentLoaded", function () {
    const emailLogin = document.getElementById('email.login');
    const passwordLogin = document.getElementById('password.login');
    const btnLogin = document.getElementById('btn.login');

    emailLogin.addEventListener('keyup', function (){
        let email = emailLogin.value;
        checkEmail(email);       
    });

    passwordLogin.addEventListener('keyup', function(){
        let pass = passwordLogin.value;
        checkPassword(pass);
    });

    btnLogin.addEventListener('click', function (){
        let email = emailLogin.value;
        let pass = passwordLogin.value;
        login(email, pass);
    });

    function checkEmail(email) {
        const formData = new FormData();
        formData.append('email', email);

        const xhr = new XMLHttpRequest();
        const url = 'modules/auth/email.php';

        return new Promise(function (resolve, reject) {
            xhr.open('POST', url, true);
            xhr.onload = function () {
                if (xhr.status === 200) {
                    resolve(xhr.responseText);
                } else {
                    reject(xhr.statusText);
                }
            };
            xhr.onerror = function () {
                reject(xhr.statusText);
            };
            xhr.send(formData);
        })
            .then(function (response) {
                if (response === email) {
                    emailLogin.classList.add('input-accent');
                    emailLogin.classList.remove('input-secondary');
                } else {
                    emailLogin.classList.remove('input-accent');
                    emailLogin.classList.add('input-secondary');
                }
            })
            .catch(function (error) {
                console.error('Error:', error);
            });
    }

    function checkPassword(pass) {
        const formData = new FormData();
        formData.append('password', pass);

        const xhr = new XMLHttpRequest();
        const url = 'modules/auth/password.php';

        return new Promise(function (resolve, reject) {
            xhr.open('POST', url, true);
            xhr.onload = function () {
                if (xhr.status === 200) {
                    resolve(xhr.responseText);
                } else {
                    reject(xhr.statusText);
                }
            };
            xhr.onerror = function () {
                reject(xhr.statusText);
            };
            xhr.send(formData);
        })
            .then(function (response) {
                if (response === "true") {
                    passwordLogin.classList.add('input-accent');
                    passwordLogin.classList.remove('input-secondary');
                } else {
                    passwordLogin.classList.remove('input-accent');
                    passwordLogin.classList.add('input-secondary');
                }
            })
            .catch(function (error) {
                console.error('Error:', error);
            });
    }
    });

    function login(email, pass) {
        const formData = new FormData();
        formData.append('email', email);
        formData.append('password', pass);

        const xhr = new XMLHttpRequest();
        const url = 'modules/login.php';

        return new Promise(function (resolve, reject) {
            xhr.open('POST', url, true);
            xhr.onload = function () {
                if (xhr.status === 200) {
                    resolve(xhr.responseText);
                } else {
                    reject(xhr.statusText);
                }
            };
            xhr.onerror = function () {
                reject(xhr.statusText);
            };
            xhr.send(formData);
        })
            .then(function (response) {
                if (response === "true") {
                    location.reload();
                }
            })
            .catch(function (error) {
                console.error('Error:', error);
            });
    }
</script>