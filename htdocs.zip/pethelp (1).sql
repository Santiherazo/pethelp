-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 09-11-2023 a las 15:07:30
-- Versión del servidor: 10.1.38-MariaDB
-- Versión de PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `pethelp`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alerta`
--

CREATE TABLE `alerta` (
  `codigo` int(11) NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `tipo` char(1) NOT NULL,
  `fecha` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `animal`
--

CREATE TABLE `animal` (
  `codigo` varchar(6) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `adopcion` tinyint(1) NOT NULL,
  `img` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `animal`
--

INSERT INTO `animal` (`codigo`, `name`, `type`, `status`, `adopcion`, `img`) VALUES
('BaxtpM', 'Baxter', 'perro', 'en recuperación', 1, 'enlace_a_la_foto_de_Baxter.jpg'),
('Bellag', 'Bella', 'gato', 'saludable', 0, 'enlace_a_la_foto_de_Bella.jpg'),
('Bentlp', 'Bentley', 'perro', 'buenas condiciones', 1, 'enlace_a_la_foto_de_Bentley.jpg'),
('CharpM', 'Charlie', 'perro', 'en recuperación', 0, 'enlace_a_la_foto_de_Charlie2.jpg'),
('Chloep', 'Chloe', 'perro', 'en recuperación', 1, 'enlace_a_la_foto_de_Chloe.jpg'),
('CleogM', 'Cleo', 'gato', 'buenas condiciones', 0, 'enlace_a_la_foto_de_Cleo.jpg'),
('CoopgM', 'Cooper', 'perro', 'en recuperación', 1, 'enlace_a_la_foto_de_Cooper.jpg'),
('Daisyp', 'Daisy', 'perro', 'buenas condiciones', 0, 'enlace_a_la_foto_de_Daisy.jpg'),
('Jasper', 'Jasper', 'gato', 'en recuperación', 0, 'enlace_a_la_foto_de_Jasper.jpg'),
('LeopMM', 'Leo', 'perro', 'en recuperación', 0, 'enlace_a_la_foto_de_Leo.jpg'),
('LilygM', 'Lily', 'gato', 'en recuperación', 0, 'enlace_a_la_foto_de_Lily.jpg'),
('LokigM', 'Loki', 'gato', 'saludable', 0, 'enlace_a_la_foto_de_Loki.jpg'),
('LunagM', 'Luna', 'gato', 'en recuperación', 0, 'enlace_a_la_foto_de_Luna.jpg'),
('Maddig', 'Maddie', 'gato', 'buenas condiciones', 0, 'enlace_a_la_foto_de_Maddie.jpg'),
('MaxpMM', 'Max', 'perro', 'buenas condiciones', 0, 'enlace_a_la_foto_de_Max.jpg'),
('MiagMM', 'Mia', 'gato', 'en recuperación', 0, 'enlace_a_la_foto_de_Mia.jpg'),
('MilogM', 'Milo', 'gato', 'saludable', 0, 'enlace_a_la_foto_de_Milo2.jpg'),
('Oliver', 'Oliver', 'gato', 'saludable', 0, 'enlace_a_la_foto_de_Oliver.jpg'),
('RockpM', 'Rocky', 'perro', 'saludable', 0, 'enlace_a_la_foto_de_Rocky3.jpg'),
('Rockyp', 'Rocky', 'perro', 'saludable', 0, 'enlace_a_la_foto_de_Rocky.jpg'),
('Sashag', 'Sasha', 'gato', 'saludable', 0, 'enlace_a_la_foto_de_Sasha.jpg'),
('SophpM', 'Sophie', 'perro', 'buenas condiciones', 0, 'enlace_a_la_foto_de_Sophie.jpg'),
('TobpM', 'Bailey', 'perro', 'buenas condiciones', 0, 'enlace_a_la_foto_de_Bailey.jpg'),
('TobpMM', 'Toby', 'perro', 'buenas condiciones', 0, 'enlace_a_la_foto_de_Toby.jpg'),
('ZoegMM', 'Zoe', 'gato', 'en recuperación', 0, 'enlace_a_la_foto_de_Zoe.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `banners`
--

CREATE TABLE `banners` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `img` varchar(255) NOT NULL,
  `status` int(1) NOT NULL,
  `orientation` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `donacion`
--

CREATE TABLE `donacion` (
  `id` varchar(255) NOT NULL,
  `fecha_donacion` date NOT NULL,
  `nombre_donante` int(11) NOT NULL,
  `estado` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `entidad`
--

CREATE TABLE `entidad` (
  `codigo` int(11) NOT NULL,
  `nit` int(13) NOT NULL,
  `razon_social` text NOT NULL,
  `direccion` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `fundacion`
--

CREATE TABLE `fundacion` (
  `nit` int(13) NOT NULL,
  `name` varchar(13) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `oficial` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `fundacion`
--

INSERT INTO `fundacion` (`nit`, `name`, `address`, `city`, `oficial`) VALUES
(2147483647, 'Fundación Amo', 'Calle del Amor Animal, Barrio de los Amantes de los Animales', 'Ciudad del Amor Animal', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ingreso`
--

CREATE TABLE `ingreso` (
  `codigo` int(4) NOT NULL,
  `tipo` char(1) NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reports`
--

CREATE TABLE `reports` (
  `id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `animal` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `reports`
--

INSERT INTO `reports` (`id`, `type`, `animal`, `description`, `image`, `location`, `latitude`, `longitude`, `date`) VALUES
(2, 'Maltrato animal', 'Perro', 'El dueÃ±o lo deja aguantando hambre, ademÃ¡s que lo tiene amarrado y en malas condiciones.', '../uploads/6547138dc6f11_Leonardo_Diffusion_XL_In_this_logo_I_want_to_make_a_diamond_si_0.png.jpg', '0', 6.303548288279657, -75.54614267315135, '2023-11-05');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `second_name` varchar(30) NOT NULL,
  `first_lastname` varchar(40) NOT NULL,
  `second_lastname` varchar(40) NOT NULL,
  `city` varchar(60) NOT NULL,
  `email` varchar(90) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `password` varchar(50) NOT NULL,
  `role` varchar(10) NOT NULL,
  `status` varchar(10) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `first_name`, `second_name`, `first_lastname`, `second_lastname`, `city`, `email`, `phone`, `password`, `role`, `status`, `date`, `time`) VALUES
(1, 'Administrador', '', '', '', '', 'admin@gmail.com', '', 'b6586f44ee6b274dc72c194a3bf01a0d', 'admin', 'active', '2023-11-04', '00:00:00');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `animal`
--
ALTER TABLE `animal`
  ADD PRIMARY KEY (`codigo`);

--
-- Indices de la tabla `entidad`
--
ALTER TABLE `entidad`
  ADD PRIMARY KEY (`codigo`);

--
-- Indices de la tabla `fundacion`
--
ALTER TABLE `fundacion`
  ADD PRIMARY KEY (`nit`);

--
-- Indices de la tabla `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `reports`
--
ALTER TABLE `reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
