<?php include 'config/pethelp.php';?>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        fetch('modules/adopted.php', {
        method: 'GET',
        })
        .then(response => response.text())
        .then(data => {
            console.log(data);
        document.getElementById('view').innerHTML = data;
        
        })
        .catch(error => {
        console.error('Error:', error);
        });
        });

</script>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>pethelp</title>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@3.9.4/dist/full.css" rel="stylesheet" type="text/css" />
    <script>
            document.addEventListener("DOMContentLoaded", function() {
        fetch('modules/adopted.php', {
        method: 'GET',
        })
        .then(response => response.text())
        .then(data => {
        document.getElementById('view').innerText = data;
        
        })
        .catch(error => {
        console.error('Error:', error);
        });
        });

    </script>
</head>
<body>
    <div class="app">
        <div class="navbar text-neutral-content" style="background: #F0F0C9;">
            <div class="navbar-start">
                <div class="dropdown">
                    <label tabindex="0" class="btn btn-ghost lg:hidden">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h8m-8 6h16" /></svg>
                    </label>
                    <ul tabindex="0" class="menu menu-sm dropdown-content mt-3 z-[1] p-2 shadow bg-base-100 rounded-box w-52">
                        <li id="nosotros" onclick="ROUTER.load('nosotros')"><a >Nosotros</a></li>
                        <li id="donaciones" onclick="ROUTER.load('donaciones')"><a >Donaciones</a>
                            <ul class="p-2">
                                <li><a>Plan Diario</a></li>
                                <li><a>Plan Semanal</a></li>
                                <li><a>Plan Mensual</a></li>
                                <li><a>Donación implementos</a></li>
                                <li><a>Afiliación</a></li>
                            </ul>
                        </li>
                        <li id="adopcion" onclick="ROUTER.load('adopcion')"><a>Adopta</a></li>
                        <li id="pqrs" onclick="ROUTER.load('pqrs')"><a>PQRS</a></li>
                        <li id="contacto" onclick="ROUTER.load('contacto')"><a>Contacto</a></li>
                    </ul>
                </div>
                <a id="home" onclick="ROUTER.load('home')" class="btn btn-ghost normal-case text-xl" style="color:#D74E09">Pet°Help</a>
            </div>
            <div class="navbar-center hidden lg:flex">
                <ul class="menu menu-horizontal px-1">
                    <li id="nosotros" onclick="ROUTER.load('nosotros')"><a>Nosotros</a></li>
                    <li tabindex="0">
                        <details>
                            <summary ><a id="donaciones" onclick="ROUTER.load('donaciones')">Donaciones</a></summary>
                            <ul class="p-2 z-[1] bg-secondary-content">
                                <li><a>Plan Diario</a></li>
                                <li><a>Plan Semanal</a></li>
                                <li><a>Plan Mensual</a></li>
                                <li><a>Donación implementos</a></li>
                                <li><a>Afiliación</a></li>
                            </ul>
                        </details>
                    </li>
                    <li id="adopcion" onclick="ROUTER.load('adopcion')"><a>Adopta</a></li>
                    <li id="pqrs" onclick="ROUTER.load('pqrs')"><a>PQRS</a></li>
                    <li id="contacto" onclick="ROUTER.load('contacto')"><a>Contacto</a></li>
                </ul>
            </div>
            <div class="navbar-end">
                <button class="btn btn-sm mr-3" style="background-color:#F2BB05;border:none;color:#F0F0C9" onclick="report_btn.showModal()">Denunciar</button>
                <?php if (!sesionActiva()) {?>
                    <div class="dropdown dropdown-end">
                        <label tabindex="0" class="btn btn-ghost btn-circle avatar">
                            <div class="avatar placeholder">
                                <div class="text-neutral-content rounded-full w-10" style="background:#D74E09; color:#F0F0C9">
                                    <span class="text-3xm">NN</span>
                                </div>
                            </div> 
                        </label>
                        <div tabindex="0" class="menu menu-sm dropdown-content mt-3 z-[1] p-4 shadow bg-secondary-content rounded-box w-60">
                            <?php include "components/login.php"; ?>
                        </div>
                    </div>
                <?php } else { ?>
                    <div class="dropdown dropdown-end">
                        <label tabindex="0" class="btn btn-ghost btn-circle avatar">
                            <div class="avatar placeholder">
                                <div class="bg-neutral-focus text-neutral-content rounded-full w-10">
                                    <span class="text-3xm"><?php echo substr($_SESSION['name'], 0, 1)?></span>
                                </div>
                            </div>
                        </label>
                        <ul tabindex="0" class="mt-3 z-[1] p-2 shadow menu menu-sm dropdown-content bg-secondary-content rounded-box w-60">
                                <li><a class="btn btn-sm">Denuncias<div class="badge badge-secondary">+99</div></a></li>
                                <li><a>Reportes</a></li>
                                <li><a>Base de datos</a></li>
                                <li><a>Adopciones</a></li>
                            <li><a id="logoutSession">Cerrar Sesión</a></li>
                        </ul>
                    </div>
                <?php } ?>
            </div>
        </div>

        <div id="content">
            <div class="carousel-item w-full">
                <div class="hero min-h-screen" style="background-image:url(https://cdn.pixabay.com/photo/2016/01/01/02/01/animal-welfare-1116205_1280.jpg);filter:blur(0.5)">
                    <div class="hero-overlay bg-opacity-60"></div>
                        <div class="hero-content text-center text-neutral-content">
                            <div class="max-w-md">
                                <h1 class="mb-5 text-5xl font-bold" style="color:#D74E09">Pet°help</h1>
                                <p class="mb-5" style="color:#F0F0C9">Nuestra misión: Rescatar, cuidar, y amar a los que no pueden pedir ayuda.</p>
                                <a class="btn" style="border: 1px solid #D74E09; background:none;color:#D74E09;font-weight:bold;" href="#donaciones">Ayúdanos a salvar vidas</a>
                            </div>
                        </div>
                    </div>
                </div> 

            <div style="background-color:#F0F0C9">
                <div class="mx-auto max-w-2xl px-4 py-16 sm:px-6 sm:py-10 lg:max-w-7xl lg:px-8">
                    <h2 class="text-2xl font-bold tracking-tight text-gray-900">Rescates Recientes</h2>
                    <div class="mt-6 grid grid-cols-1 gap-x-6 gap-y-10 sm:grid-cols-2 lg:grid-cols-4 xl:gap-x-8">
                        
                        <div class="group relative">
                            <div class="aspect-h-1 aspect-w-1 w-full overflow-hidden rounded-md bg-gray-200 lg:aspect-none group-hover:opacity-75 lg:h-80">
                                <img src="https://img.freepik.com/free-photo/cute-dogs-fence-waiting-be-adopted_23-2148683005.jpg?w=740&t=st=1699514603~exp=1699515203~hmac=7536bceafefad1592cac306b50a98c55de83fee6dfa7a6dd7620bcd6bd7e059d" alt="Front of men&#039;s Basic Tee in black." class="h-full w-full object-cover object-center lg:h-full lg:w-full">
                            </div>
                            <div class="mt-4 flex justify-between">
                                <div>
                                    <h3 class="text-sm text-gray-700">
                                        <a href="#">
                                        <span aria-hidden="true" class="absolute inset-0"></span>Nombre: Billie</a>
                                    </h3>
                                    <p class="mt-1 text-sm text-gray-500">Rescatado por: Maltrato animal</p>
                                </div>
                                <p class="text-sm font-medium text-gray-900">Edad: 2 Meses</p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            <div class="bg-white py-24 sm:py-10" style="background:#D74E09;">
                <div class="mx-auto max-w-7xl px-6 lg:px-8">
                    <dl class="grid grid-cols-1 gap-x-8 gap-y-16 text-center lg:grid-cols-3">
                        <div class="mx-auto flex max-w-xs flex-col gap-y-4">
                            <dt class="text-base leading-7 text-gray-600" style="color:#F0F0C9">Mascotas rescatados</dt>
                            <dd class="order-first text-3xl font-semibold tracking-tight text-gray-900 sm:text-5xl" style="color:#F0F0C9">+400</dd>
                        </div>
                        <div class="mx-auto flex max-w-xs flex-col gap-y-4">
                            <dt class="text-base leading-7 text-gray-600" style="color:#F0F0C9">Mascotas adoptadas</dt>
                            <dd class="order-first text-3xl font-semibold tracking-tight text-gray-900 sm:text-5xl" style="color:#F0F0C9">+100</dd>
                        </div>
                        <div class="mx-auto flex max-w-xs flex-col gap-y-4">
                            <dt class="text-base leading-7 text-gray-600" style="color:#F0F0C9">Mascotas beneficiadas</dt>
                            <dd class="order-first text-3xl font-semibold tracking-tight text-gray-900 sm:text-5xl" style="color:#F0F0C9">+1000</dd>
                        </div>
                    </dl>
                </div>
            </div>

            <div class="overflow-hidden bg-white py-24 sm:py-32">
                <div class="mx-auto max-w-7xl px-6 lg:px-8">
                    <div class="mx-auto grid max-w-2xl grid-cols-1 gap-x-8 gap-y-16 sm:gap-y-20 lg:mx-0 lg:max-w-none lg:grid-cols-2">
                        <div class="lg:pr-8 lg:pt-4">
                            <div class="lg:max-w-lg">
                                <h2 class="text-base font-semibold leading-7 text-indigo-600" style="color:#D74E09;font-size:20px">Pet°Help: Tu Compañero en la Protección Animal</h2>
                                <p class="mt-2 text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">¿Quienes somos?</p>
                                <p class="mt-6 text-lg leading-8 text-gray-600">En PetHelp, nuestra misión es simple pero poderosa: defender y proteger a los animales más vulnerables de nuestra sociedad. Como una fundación dedicada al bienestar animal, nos enorgullece ser la voz y el refugio para aquellos que no pueden hablar por sí mismos.</p>
                                <dl class="mt-10 max-w-xl space-y-8 text-base leading-7 text-gray-600 lg:max-w-none">
                                    <div class="relative pl-9">
                                        <dt class="inline font-semibold text-gray-900">
                                            <svg class="absolute left-1 top-1 h-5 w-5 text-indigo-600" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                                <path fill-rule="evenodd" d="M10 1a4.5 4.5 0 00-4.5 4.5V9H5a2 2 0 00-2 2v6a2 2 0 002 2h10a2 2 0 002-2v-6a2 2 0 00-2-2h-.5V5.5A4.5 4.5 0 0010 1zm3 8V5.5a3 3 0 10-6 0V9h6z" clip-rule="evenodd" />
                                            </svg>
                                            Empatía:
                                        </dt>
                                        <dd class="inline"> La empatía es una cualidad fundamental de PetHelp, que se refleja en su trato compasivo hacia cada ser viviente.</dd>
                                    </div>
                                    <div class="relative pl-9">
                                        <dt class="inline font-semibold text-gray-900">
                                            <svg class="absolute left-1 top-1 h-5 w-5 text-indigo-600" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                                <path fill-rule="evenodd" d="M10 1a4.5 4.5 0 00-4.5 4.5V9H5a2 2 0 00-2 2v6a2 2 0 002 2h10a2 2 0 002-2v-6a2 2 0 00-2-2h-.5V5.5A4.5 4.5 0 0010 1zm3 8V5.5a3 3 0 10-6 0V9h6z" clip-rule="evenodd" />
                                            </svg>
                                            Trabajo en Equipo: 
                                        </dt>
                                        <dd class="inline">El equipo de PetHelp trabaja unido y de manera colaborativa para alcanzar sus objetivos y brindar el mejor cuidado posible a los animales..</dd>
                                    </div>
                                    <div class="relative pl-9">
                                        <dt class="inline font-semibold text-gray-900">
                                            <svg class="absolute left-1 top-1 h-5 w-5 text-indigo-600" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                                <path fill-rule="evenodd" d="M10 1a4.5 4.5 0 00-4.5 4.5V9H5a2 2 0 00-2 2v6a2 2 0 002 2h10a2 2 0 002-2v-6a2 2 0 00-2-2h-.5V5.5A4.5 4.5 0 0010 1zm3 8V5.5a3 3 0 10-6 0V9h6z" clip-rule="evenodd" />
                                            </svg>
                                            Innovación y Mejora Continua:
                                        </dt>
                                        <dd class="inline">PetHelp busca constantemente nuevas formas de mejorar y ampliar su impacto en la protección animal.</dd>
                                    </div>
                                </dl>
                            </div>
                        </div>
                        <img src="https://img.freepik.com/free-photo/man-hugging-his-friendly-pitbull_23-2149131403.jpg?w=740&t=st=1699512753~exp=1699513353~hmac=462d0976f65bdd1ecad9f0b0f87080e009a1d8922785b22af08e5b466fb7e191" alt="Product screenshot" class="w-[48rem] max-w-none rounded-xl shadow-xl ring-1 ring-gray-400/10 sm:w-[57rem] md:-ml-4 lg:-ml-0" width="2432" height="1442">
                    </div>
                </div>
            </div>


            <div style="background:#D74E09">
                <div class="mx-auto max-w-7xl py-24 sm:px-6 sm:py-10 lg:px-8">
                    <div class="relative isolate overflow-hidden bg-gray-900 px-6 pt-16 shadow-2xl sm:rounded-3xl sm:px-16 md:pt-24 lg:flex lg:gap-x-20 lg:px-24 lg:pt-0" style="background:#F0F0C9">
                        <div class="mx-auto max-w-md text-center lg:mx-0 lg:flex-auto lg:py-32 lg:text-left">
                            <h2 style="color:#434343" class="text-3xl font-bold tracking-tight text-white sm:text-4xl">¡Llévame contigo!<br>Seré tu mejor compañia.</h2>
                            <p style="color:#434343" class="mt-6 text-lg leading-8 text-gray-300">Las almas más leales no tienen pedigrí, tienen amor para dar.</p>
                            <div class="mt-10 flex items-center justify-center gap-x-6 lg:justify-start">
                                <a href="#" style="color:#434343" class="rounded-md bg-white px-3.5 py-2.5 text-sm font-semibold text-gray-900 shadow-sm hover:bg-gray-100 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white">Adóptame</a>
                            </div>
                        </div>
                        <div class="relative mt-16 h-80 lg:mt-8">
                            <img class="absolute left-0 top-0 w-[29rem] max-w-none rounded-md bg-white/5 ring-1 ring-white/10" src="https://img.freepik.com/free-photo/adorable-dog-with-adopt-me-banner_23-2148699618.jpg?w=740&t=st=1699513087~exp=1699513687~hmac=f01166e091ec33de73d5364a9fb9c338ea892fdedc423d1351a27d3ff8373608" alt="App screenshot">
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <footer class="footer footer-center p-10 bg-primary text-primary-content" style="background:#F0F0C9; color:#434343">
            <aside>
                <p class="font-bold">Fundación Pet°Help <br/>Patitas amigas desde 2021.</p> 
                <p>Copyright © 2023 - All right reserved</p>
            </aside> 
            <nav>
                <div class="grid grid-flow-col gap-4">
                    <a><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="fill-current"><path d="M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.212 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1.562 2.457-2.549z"></path></svg></a> 
                    <a><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="fill-current"><path d="M19.615 3.184c-3.604-.246-11.631-.245-15.23 0-3.897.266-4.356 2.62-4.385 8.816.029 6.185.484 8.549 4.385 8.816 3.6.245 11.626.246 15.23 0 3.897-.266 4.356-2.62 4.385-8.816-.029-6.185-.484-8.549-4.385-8.816zm-10.615 12.816v-8l8 3.993-8 4.007z"></path></svg></a> 
                    <a><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="fill-current"><path d="M9 8h-3v4h3v12h5v-12h3.642l.358-4h-4v-1.667c0-.955.192-1.333 1.115-1.333h2.885v-5h-3.808c-3.596 0-5.192 1.583-5.192 4.615v3.385z"></path></svg></a>
                </div>
            </nav>
        </footer>
    </div>

    <dialog id="register_modal" class="modal">
        <div class="modal-box bg-secondary-content">
            <form method="dialog">
                <button class="btn btn-sm btn-circle btn-ghost absolute right-2 top-2">✕</button>
            </form>
        </div>
    </dialog>

    <dialog id="report_btn" class="modal text-base-100">
        <div class="modal-box bg-secondary-content">
            <form method="dialog">
                <button class="btn btn-sm btn-circle btn-ghost absolute right-2 top-2">✕</button>
            </form>
            <h3 class="font-bold text-center text-lg mb-3">Denunciar</h3>
            <div class="w-full flex justify-center mb-4">
                <div class="w-80 p-2 ">
                    <div class="form-control w-full max-w-xs">
                        <label class="label">
                            <span class="label-text text-base-100">Tipo de Denuncia</span>
                        </label>
                        <select id="type.report" class="select select-bordered bg-secondary-content text-base-100">
                            <option disabled selected>Elige una opción</option>
                            <option>Maltrato animal</option>
                            <option>Abandono</option>
                        </select>
                    </div>
                    <div class="form-control w-full max-w-xs">
                        <label class="label">
                            <span class="label-text text-base-100">Tipo de animal</span>
                        </label>
                        <select id="animal.report" class="select select-bordered bg-secondary-content text-base-100">
                            <option disabled selected>Elige una opción</option>
                            <option>Perro</option>
                            <option>Gato</option>
                            <option>Otros</option>
                        </select>
                    </div>
                    <div class="form-control">
                        <label class="label">
                            <span class="label-text text-base-100">Descripción de los hechos</span>
                        </label>
                        <textarea id="description.report" class="textarea textarea-bordered h-60 bg-secondary-content"></textarea>
                    </div>
                    <div class="form-control w-full max-w-xs">
                        <label class="label">
                            <span class="label-text text-base-100">Anexar Evidencias</span>
                        </label>
                        <input type="file" id="fileUpload" multiple class="file-input file-input-sm bg-secondary-content file-input-bordered w-full max-w-xs" />
                    </div>
                    <div class="form-control w-full max-w-xs">
                        <label class="label">
                            <span class="label-text text-base-100">Ingresa Dirección</span>
                        </label>
                        <input id="ubi.report" type="text" class="input input-bordered w-full max-w-xs input-sm bg-secondary-content" />
                        <div class="divider">OR</div>
                        <button id="gps.report" class="btn btn-sm btn-outline text-base-100">Compartir Ubicación</button>
                        <iframe id="maps" src="" frameborder="0"></iframe>
                    </div>
                    <button id="submit_demand" class="btn btn-sm btn-block btn-outline mt-4 text-base-100">Finalizar Denuncia</button>
                </div>
            </div>
        </div>
    </dialog>

    <script src="assets/js/router.js"></script>
    <script src="assets/js/app.js"></script>
    <script src="https://cdn.tailwindcss.com"></script>
</body>
</html>
