<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $typeReport = $_POST['typeReport'];
    $animal = $_POST['animal'];
    $description = $_POST['description'];
    $location = $_POST['location'];
    $latitude = $_POST['latitude'];
    $longitude = $_POST['longitude'];
    $date = date("Y-m-d H:i:s");

    if (!empty($_FILES['file']['name'][0])) {
        $uploadDir = '../uploads/';
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        $maxSize = 5 * 1024 * 1024;

        $fileUploadStatus = array();
        $uploadFile = "";
        foreach ($_FILES['file']['name'] as $key => $fileName) {
            $tmpFilePath = $_FILES['file']['tmp_name'][$key];
            $fileType = $_FILES['file']['type'][$key];
            $fileSize = $_FILES['file']['size'][$key];

            if (in_array($fileType, $allowedTypes) && $fileSize <= $maxSize) {
                $uploadFile = $uploadDir . uniqid() . '_' . $fileName . '.jpg';
                if (move_uploaded_file($tmpFilePath, $uploadFile)) {
                    $fileUploadStatus[] = ['success' => true, 'path' => $uploadFile];
                } else {
                    $fileUploadStatus[] = ['success' => false, 'message' => 'Error al subir la imagen ' . $fileName];
                }
            } else {
                $fileUploadStatus[] = ['success' => false, 'message' => 'Tipo o tamaño de archivo no válido: ' . $fileName];
            }
        }
    } else {
        $fileUploadStatus[] = ['success' => false, 'message' => 'No se han seleccionado archivos para subir.'];
    }

    $db = new mysqli('localhost', 'root', '', 'pethelp');
    if ($db->connect_error) {
        die('Conexión fallida: ' . $db->connect_error);
    }

    $query = "INSERT INTO reports (type, animal, description, image, location, latitude, longitude, date) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $db->prepare($query);
    $stmt->bind_param("ssssddss", $typeReport, $animal, $description, $uploadFile, $location, $latitude, $longitude, $date);

    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error en la inserción: ' . $stmt->error]);
    }

    $stmt->close();
    $db->close();
} else {
    http_response_code(400);
    echo "Error: Solicitud no válida.";
}
?>
