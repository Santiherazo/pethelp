<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fnameInput = $_POST['fnameInput'];
    $snameInput = $_POST['snameInput'];
    $flastnameInput = $_POST['flastnameInput'];
    $slastnameInput = $_POST['slastnameInput'];
    $cityInput = $_POST['cityInput'];
    $emailInput = $_POST['emailInput'];
    $phoneInput = $_POST['phoneInput'];
    $passwordInput = $_POST['passwordInput'];
    $checked = $_POST['checked'];
    $matched = $_POST['matched'];
    $role = 'user';
    $status = 'active';
    date_default_timezone_set('America/Bogota');
    $date = date("Y-m-d");
    $time = date("H:i:s");
    $passwordInputMD5 = md5($passwordInput);

    if($checked && $matched){
    $db = new mysqli('localhost', 'root', '', 'pethelp');

    if ($db->connect_error) {
        die('Conexión fallida: ' . $db->connect_error);
    }
    
    $query = "INSERT INTO users (first_name, second_name, first_lastname, second_lastname, city, email, phone, password, role, status, date, time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $db->prepare($query);

    $stmt->bind_param("ssssssssssss", $fnameInput, $snameInput, $flastnameInput, $slastnameInput, $cityInput, $emailInput, $phoneInput, $passwordInputMD5, $role, $status, $date, $time);

    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error en la inserción: ' . $stmt->error]);
    }

    $stmt->close();
    $db->close();
}
} else {
    http_response_code(400);
    echo "Error: Solicitud no válida.";
}
?>