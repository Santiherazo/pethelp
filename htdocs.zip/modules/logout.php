<?php

session_start();

if (isset($_SESSION['name'])) {
    session_destroy();

    $response['success'] = true;
    $response['message'] = 'Sesión cerrada con éxito';
} else {
    $response['success'] = false;
    $response['message'] = 'No se encontró una sesión activa';
}

header('Content-Type: application/json');

echo json_encode($response);
?>
