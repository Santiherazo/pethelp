<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    
$db = mysqli_connect('localhost', 'root', '', 'pethelp');
$query = "SELECT email FROM users WHERE email LIKE LOWER('%".$email."%')";

$result = mysqli_query($db, $query);
while($row = mysqli_fetch_array($result)) {
    echo $row['email'];
}


if(!$result) {
    die('Query Error' . mysqli_error($db));
}

} else {
    http_response_code(400);
    echo "Error: Solicitud no válida.";
}