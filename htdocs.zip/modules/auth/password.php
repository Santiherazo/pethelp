<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = $_POST['password'];
    $passMD5 = md5($password);
    
    $db = mysqli_connect('localhost', 'root', '', 'pethelp');
    
    if (!$db) {
        die('Error al conectar a la base de datos: ' . mysqli_connect_error());
    }
    
    $query = "SELECT password FROM users WHERE password = '$passMD5'";
    $result = mysqli_query($db, $query);
    
    if (!$result) {
        die('Error en la consulta: ' . mysqli_error($db));
    }
    
    if (mysqli_num_rows($result) > 0) {
        echo "true";
    } else {
        echo "false";
    }
    
    mysqli_close($db);
} else {
    http_response_code(400);
    echo "Error: Solicitud no válida.";
}
?>
