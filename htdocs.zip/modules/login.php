<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $passMD5 = md5($password);
  
    $db = mysqli_connect('localhost', 'root', '', 'pethelp');
    $query = "SELECT * FROM users WHERE password = '$passMD5' AND email = '$email'";
    $result = mysqli_query($db, $query);

    if (!$result) {
        die('Query Error: ' . mysqli_error($db));
    }

    $row = mysqli_fetch_array($result);

    if ($row) {

        session_start();
        $_SESSION['name'] = $row['first_name'];
        $_SESSION['role'] = $row['role'];
        echo "true";
    } else {
        echo "false";
    }
} else {
    http_response_code(400);
    echo "Error: Solicitud no válida.";
}
